$(document).ready(function(){

  $('#formcall #phone').keyup(
        function(){
           number = $(this).val();
var re = /^[0-9,(,),-,]*$/;
          // if($(number).length < 7){$('#submitit').text(number);}else{$('#submitit').text('no');}
           if($("#phone").val().length < 7 || !re.test(number))
           {$('#submitit').text('Телефон должен быть вида: (xxx)xxx-xx-xx или xxx-xx-xx');}else{$('#submitit').html('<input type="submit" name="submit" id="submit"  value="Перезвоните мне!">');}
                   }
              )

   $("#formcall").ajaxForm(function() {
     $('#callls').html('');
     $('p#res').html("Спасибо! Мы Вам перезвоним в кратчайшие сроки.");
   });
});