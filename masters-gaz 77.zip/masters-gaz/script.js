var global_count_pict = 0;
var global_z_count = 0;
var global_x_count = 0;

function ChangePict()
{
    var pict = document.getElementById("copyright-img");
    
    var str = pict.src;
    
    var pictNum = str[str.length-5];
    
    if(pictNum == "z")
    {
        if(global_z_count == 1)
            pictNum = 0;
        else
            global_z_count = 1;
    }
    
    if(pictNum == "x")
    {
        if(global_x_count == 1)
            pictNum = 0;
        else
            global_x_count = 1;
    }
    
    if(pictNum != "z" && pictNum != "x" && pictNum != "c")
    {
        pictNum = Math.floor(pictNum);
        pictNum++;
        
        if(pictNum > 9)
            pictNum = 1;
    }    
    
    if(global_count_pict == 10)
        pictNum = "z";
        
    if(global_count_pict == 20)
        pictNum = "x";
        
    if(global_count_pict == 30)
        pictNum = "c";
        
    var newStr = "";
    
    if(pictNum == "z" || pictNum == "x" || pictNum == "c")
    {
        document.getElementById("copyright-img").style.marginBottom = "-4px";
    }
    else
    {
        document.getElementById("copyright-img").style.marginBottom = "-2px";
    }
    
    for(var i = 0; i < str.length; i++)
    {
        if(i == str.length-5)
            newStr = newStr + pictNum;
        else
            newStr = newStr + str[i];
    }
    
       
    pict.src = newStr; 
    
    global_count_pict++;
    
    
}