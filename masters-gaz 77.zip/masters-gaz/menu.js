$(document).ready( function () {	
	$('.callme a').click(
		function () {
			$('.call-form').slideDown(400);
		});
	$('.call-form a.close').click(
		function () {
			$('.call-form').slideUp(100);
		});
 



	$('#menu li').hover(
		function () {
			$('ul', this).slideDown(100);
		}, 
		function () {
			$('ul', this).slideUp(50);			
		}); 
});